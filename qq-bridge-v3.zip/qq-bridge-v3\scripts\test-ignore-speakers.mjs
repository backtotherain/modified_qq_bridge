// 「群里不回应某些人」的回归：硬闸门（不唤醒）+ 软提示（唤醒包里写明名单）。
// 用真实 bridge 代码跑在 vm 沙箱里，不连 QQ / DSH。
// 用法：node scripts/test-ignore-speakers.mjs
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { bridgeHarness } from './audit-bridge-harness.mjs';

let failed = 0;
const check = async (name, fn) => {
  try { await fn(); console.log(`✅ ${name}`); } catch (error) { failed += 1; console.log(`❌ ${name} — ${error?.message ?? error}`); }
};

const GROUP = '456';
const IGNORED = '999';
const NORMAL = '777';

const mkEvent = (userId, text) => ({
  self_id: 111,
  user_id: Number(userId),
  group_id: Number(GROUP),
  message_id: 1000 + Number(userId),
  sender: { user_id: Number(userId), nickname: `U${userId}`, card: '' },
  message: [{ type: 'text', data: { text } }]
});

const h = await bridgeHarness({
  config: {
    allow: { private: ['123'], groups: [GROUP] },
    socialV2: { ignore: { speakersByGroup: { [GROUP]: [IGNORED] } } }
  }
});
h.setMode('reserved2');

await check('被忽略的人说话：消息仍入库', async () => {
  await h.handleIncoming('group', GROUP, mkEvent(IGNORED, '这条不该触发回合'), h.cfg);
  const st = h.getSocialV2State(`group:${GROUP}`);
  assert.equal(st.unread.length, 1, '被忽略的消息必须继续入库（上下文/记忆要完整）');
});

await check('被忽略的人说话：不排唤醒', async () => {
  const st = h.getSocialV2State(`group:${GROUP}`);
  assert.equal(st.pendingWakeTimer, null, '被忽略的人不得触发唤醒');
});

await check('被忽略的人说话：不消耗 bootstrap 引导回合', async () => {
  const st = h.getSocialV2State(`group:${GROUP}`);
  assert.equal(st.bootstrapSent, false, 'bootstrapSent 必须保持 false，等正常人触发');
});

await check('正常人说话：照常排唤醒', async () => {
  await h.handleIncoming('group', GROUP, mkEvent(NORMAL, '@机器人 在吗'), h.cfg);
  const st = h.getSocialV2State(`group:${GROUP}`);
  assert.ok(st.pendingWakeTimer, '正常人说话应排出唤醒定时器');
  assert.equal(st.unread.length, 2);
});

await check('判定函数：命中/不命中/私聊不适用', async () => {
  assert.equal(h.isIgnoredSpeakerV2(`group:${GROUP}`, 'group', IGNORED), true);
  assert.equal(h.isIgnoredSpeakerV2(`group:${GROUP}`, 'group', NORMAL), false);
  assert.equal(h.isIgnoredSpeakerV2('private:999', 'private', IGNORED), false, '私聊不走群名单（整会话屏蔽用 deny.private）');
  // 跨 vm realm 的数组原型不同，deepEqual 会假失败，统一按 JSON 比
  assert.equal(JSON.stringify(h.ignoredSpeakerIdsV2(`group:${GROUP}`, 'group')), JSON.stringify([IGNORED]));
});

await check('key 写成 group:群号 也能命中（两种写法都认）', async () => {
  const keyed = await bridgeHarness({
    config: { allow: { private: ['123'], groups: [GROUP] }, socialV2: { ignore: { speakersByGroup: { [`group:${GROUP}`]: [IGNORED] } } } }
  });
  keyed.setMode('reserved2');
  assert.equal(keyed.isIgnoredSpeakerV2(`group:${GROUP}`, 'group', IGNORED), true);
});

await check('唤醒提示词里写明「不回应」名单', async () => {
  const prompt = h.buildWakePromptV2(`group:${GROUP}`, 'bootstrap');
  assert.match(prompt, /【不回应】/, '唤醒包必须包含不回应条款');
  assert.match(prompt, new RegExp(IGNORED), '必须点出具体 QQ 号');
});

await check('没有被忽略的群：提示词里不出现该条款', async () => {
  const clean = await bridgeHarness({ config: { allow: { private: ['123'], groups: ['789'] } } });
  clean.setMode('reserved2');
  const prompt = clean.buildWakePromptV2('group:789', 'bootstrap');
  assert.ok(!prompt.includes('【不回应】'), '没配置名单就不该多占字符');
});

await check('拍一拍也走同一份名单（不能绕过）', async () => {
  const poke = await bridgeHarness({
    config: { allow: { private: ['123'], groups: [GROUP] }, socialV2: { ignore: { speakersByGroup: { [GROUP]: [IGNORED] } } } }
  });
  poke.setMode('reserved2');
  await poke.handlePokeNotice({ sub_type: 'poke', self_id: 111, group_id: Number(GROUP), sender_id: Number(IGNORED), target_id: 111, action: '拍了拍' });
  const st = poke.getSocialV2State(`group:${GROUP}`);
  assert.equal(st.pendingWakeTimer, null, '被忽略的人拍一拍不得唤醒');
});

await check('手改 config.json 立即生效（不用重启）', async () => {
  const live = await bridgeHarness({ config: { allow: { private: ['123'], groups: [GROUP] }, socialV2: { ignore: { speakersByGroup: { [GROUP]: [] } } } } });
  live.setMode('reserved2');
  assert.equal(live.isIgnoredSpeakerV2(`group:${GROUP}`, 'group', IGNORED), false, '初始为空名单');
  // 模拟运维直接编辑 config.json：只改 ignore 段，其它键原样保留
  const cfg = JSON.parse(fs.readFileSync(live.cfgPath, 'utf8'));
  cfg.socialV2.ignore.speakersByGroup[GROUP] = [IGNORED];
  fs.writeFileSync(live.cfgPath, JSON.stringify(cfg, null, 2));
  // 文件 mtime 粒度可能只有 1 秒：显式推进一下，避免测试在同一 tick 内假失败
  const future = new Date(Date.now() + 2000);
  fs.utimesSync(live.cfgPath, future, future);
  assert.equal(live.isIgnoredSpeakerV2(`group:${GROUP}`, 'group', IGNORED), true, '改完文件应当立刻命中');
  await live.handleIncoming('group', GROUP, mkEvent(IGNORED, '改完名单后这条不该唤醒'), live.cfg);
  assert.equal(live.getSocialV2State(`group:${GROUP}`).pendingWakeTimer, null, '热读后仍必须是硬闸门');
  await live.close();
});

await check('"*" 通配：所有群一起生效，且与按群配置取并集', async () => {
  const h2 = await bridgeHarness({
    config: { allow: { private: ['123'], groups: ['456', '457'] }, socialV2: { ignore: { speakersByGroup: { '*': ['111222'], '457': ['333444'] } } } }
  });
  h2.setMode('reserved2');
  assert.equal(h2.isIgnoredSpeakerV2('group:456', 'group', '111222'), true, '通配应对任意群生效');
  assert.equal(h2.isIgnoredSpeakerV2('group:457', 'group', '333444'), true, '按群配置仍然生效');
  assert.equal(h2.isIgnoredSpeakerV2('group:457', 'group', '111222'), true, '两者取并集');
  assert.equal(h2.isIgnoredSpeakerV2('group:456', 'group', '999999'), false, '不在名单里的人照常唤醒');
  await h2.close();
});

console.log(failed ? `\n❌ ${failed} 项失败` : '\n✅ 不回应名单全部通过');
process.exit(failed ? 1 : 0);
