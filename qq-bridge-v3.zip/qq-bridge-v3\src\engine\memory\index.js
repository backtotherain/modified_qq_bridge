// 记忆检索的纯函数层：中文 bigram 倒排 + 三要素打分 + 艾宾浩斯遗忘曲线。
//
// 打分抄的是两份公开研究，公式自己实现（不搬代码）：
//   · Generative Agents (Park et al., 2023)：检索分 = 相关性 + 重要性 + 新近度，
//     三者归一化后加权求和。原论文等权，这里按群聊场景给了 0.5/0.3/0.2。
//   · MemoryBank (Zhong et al., 2305.10250)：保留率 R = e^(-t/S)，S 是记忆强度，
//     每被召回一次 S += 1 且 t 归零 ⇒ 反复用到的东西越来越难忘（半衰期翻倍）。
//
// 为什么不用 embedding：一次 embedding 就是一次 API 调用，和省钱目标相反；
// 群聊检索以实体/关键词为主，bigram + idf 够用。真到"记得意思忘了词"再上向量。
//
// 分词策略（中文无空格）：
//   · CJK 连续串切 bigram（"赛博朋克" → 赛博/博朋/朋克），另保留整串作为一个 token；
//   · 拉丁字母/数字按词切（"DLC"、"4090"）；
//   · 单字查询（如"贵"）退化成单字 token。
//   bigram 的代价是「词界错位」会带来噪音，用 idf 与长度归一化压掉。

const CJK_RE = /[\u3400-\u4dbf\u4e00-\u9fff\uf900-\ufaff\u3040-\u30ff]/;
const ASCII_WORD_RE = /[a-z0-9][a-z0-9_+#.-]*/gi;

/** 默认半衰期（小时）：2 天。S 每次召回 +1，实际半衰期 = 48h × S。 */
export const DEFAULT_HALF_LIFE_HOURS = 48;
/** 三要素权重：相关性 / 重要性 / 新近度。 */
export const DEFAULT_WEIGHTS = { rel: 0.5, imp: 0.3, rec: 0.2 };
/** 重要性缺省值（1~10），未打分时按 5 处理。 */
export const DEFAULT_IMPORTANCE = 5;

function isCjk(ch) {
  return CJK_RE.test(ch);
}

/**
 * 把一段文本切成检索 token。
 * @returns {string[]} 去重后的 token（保序）
 */
export function tokenize(text) {
  const src = String(text ?? '').toLowerCase();
  if (!src) return [];
  const tokens = new Set();
  for (const m of src.matchAll(ASCII_WORD_RE)) {
    if (m[0].length >= 2) tokens.add(m[0]);
  }
  let run = '';
  const flush = () => {
    if (!run) return;
    if (run.length === 1) tokens.add(run);
    else {
      for (let i = 0; i + 1 < run.length; i += 1) tokens.add(run.slice(i, i + 2));
      if (run.length >= 3 && run.length <= 8) tokens.add(run);
    }
    run = '';
  };
  for (const ch of src) {
    if (isCjk(ch)) run += ch;
    else flush();
  }
  flush();
  return [...tokens];
}

/** 查询分词：额外允许 1 个 CJK 字符的单字查询。 */
export function tokenizeQuery(text) {
  const tokens = tokenize(text);
  const src = String(text ?? '').trim();
  if (src.length === 1 && isCjk(src)) tokens.push(src.toLowerCase());
  return [...new Set(tokens)];
}

/**
 * 「词形」分词：只出 ASCII 词与 2~8 字的 CJK 连续串，不出 bigram。
 * 群情摘要用——digest 的高频词混进 bigram 就成了「我上 上周 周买」这种碎片。
 */
export function tokenizeWords(text) {
  const src = String(text ?? '').toLowerCase();
  if (!src) return [];
  const out = new Set();
  for (const m of src.matchAll(ASCII_WORD_RE)) {
    if (m[0].length >= 2) out.add(m[0]);
  }
  let run = '';
  const flush = () => {
    if (run.length >= 2 && run.length <= 8) out.add(run);
    run = '';
  };
  for (const ch of src) {
    if (isCjk(ch)) run += ch;
    else flush();
  }
  flush();
  return [...out];
}

/**
 * 构建倒排索引。
 * @param {Array<{text?:string, plain?:string}>} messages
 */
export function buildIndex(messages) {
  const postings = new Map();
  const df = new Map();
  const lengths = [];
  let totalLen = 0;
  const list = Array.isArray(messages) ? messages : [];
  for (let i = 0; i < list.length; i += 1) {
    const text = list[i]?.text ?? list[i]?.plain ?? '';
    const tokens = tokenize(text);
    lengths.push(tokens.length);
    totalLen += tokens.length;
    for (const tok of tokens) {
      let arr = postings.get(tok);
      if (!arr) { arr = []; postings.set(tok, arr); }
      const last = arr[arr.length - 1];
      if (last && last[0] === i) { if (last[1] < 3) last[1] += 1; continue; }
      arr.push([i, 1]);
      df.set(tok, (df.get(tok) ?? 0) + 1);
    }
  }
  return { postings, df, lengths, n: list.length, avgLen: list.length ? totalLen / list.length : 0 };
}

/** 增量加一篇文档到已有索引（追加场景，不重建）。 */
export function addDocument(index, text) {
  const tokens = tokenize(text);
  const docIdx = index.n;
  index.lengths.push(tokens.length);
  index.avgLen = index.n === 0 ? tokens.length : (index.avgLen * index.n + tokens.length) / (index.n + 1);
  index.n += 1;
  for (const tok of tokens) {
    let arr = index.postings.get(tok);
    if (!arr) { arr = []; index.postings.set(tok, arr); }
    arr.push([docIdx, 1]);
    index.df.set(tok, (index.df.get(tok) ?? 0) + 1);
  }
  return docIdx;
}

/** 记忆强度 S：缺省 1，每次召回 +1（上限 10，避免旧梗永不过期）。 */
export function strengthOf(msg) {
  const s = Number(msg?.s);
  return Number.isFinite(s) && s >= 1 ? Math.min(10, s) : 1;
}

/**
 * 新近度：R = 2^(-ageHours / (halfLife × S))。
 * 等价于 MemoryBank 的 e^(-t/S)：S 翻倍 ⇒ 半衰期翻倍（被反复召回的东西更难忘）。
 */
export function recencyOf(msg, { now = Date.now(), halfLifeHours = DEFAULT_HALF_LIFE_HOURS } = {}) {
  const ts = Number(msg?.ts ?? msg?.time ?? 0);
  if (!Number.isFinite(ts) || ts <= 0) return 0.5;
  const ageHours = Math.max(0, (now - ts) / 3600000);
  const hl = Math.max(1, halfLifeHours) * strengthOf(msg);
  return Math.pow(2, -ageHours / hl);
}

/** 重要性归一化到 (0,1]。 */
export function importanceOf(msg) {
  const imp = Number(msg?.imp);
  const value = Number.isFinite(imp) ? Math.min(10, Math.max(1, imp)) : DEFAULT_IMPORTANCE;
  return value / 10;
}

/**
 * 检索并打分。
 *
 * 流程：先按关键词算相关性（idf × √tf / √docLen），再取候选集；
 * 候选内部把相关性按最大值归一化，然后
 *   score = w.rel·relNorm + w.imp·importance + w.rec·recency
 * 这样"重要但略旧"的东西能压过"无关但刚说"的东西，而"刚从眼前飘过"仍有一票。
 *
 * @param {ReturnType<typeof buildIndex>} index
 * @param {Array<object>} messages
 * @param {string} query
 * @param {{limit?:number, sinceMs?:number, untilMs?:number, speaker?:string, now?:number,
 *          halfLifeHours?:number, weights?:{rel:number,imp:number,rec:number}, ownerOnly?:boolean}} [opts]
 * @returns {Array<{index:number, message:object, score:number, matched:string[]}>}
 */
export function searchIndex(index, messages, query, opts = {}) {
  const {
    limit = 8, sinceMs = 0, untilMs = Number.POSITIVE_INFINITY,
    speaker = '', now = Date.now(), halfLifeHours = DEFAULT_HALF_LIFE_HOURS,
    weights = DEFAULT_WEIGHTS, ownerOnly = false
  } = opts;
  const qTokens = tokenizeQuery(query);
  if (!qTokens.length || !index || !index.n) return [];
  const w = { ...DEFAULT_WEIGHTS, ...(weights ?? {}) };
  const norm = String(query ?? '').trim().toLowerCase();
  const rawRel = new Map();
  const matchedByDoc = new Map();
  const idf = (tok) => Math.log((index.n + 1) / ((index.df.get(tok) ?? 0) + 1)) + 1;

  for (const tok of qTokens) {
    const arr = index.postings.get(tok);
    if (!arr) continue;
    const weight = idf(tok);
    for (const [docIdx, tf] of arr) {
      const msg = messages[docIdx];
      if (!msg) continue;
      const ts = Number(msg.ts ?? msg.time ?? 0);
      if (ts && (ts < sinceMs || ts > untilMs)) continue;
      const len = Math.max(8, Number(index.lengths?.[docIdx]) || index.avgLen || 8);
      rawRel.set(docIdx, (rawRel.get(docIdx) ?? 0) + (weight * Math.sqrt(tf)) / Math.sqrt(len));
      let hit = matchedByDoc.get(docIdx);
      if (!hit) { hit = []; matchedByDoc.set(docIdx, hit); }
      if (!hit.includes(tok)) hit.push(tok);
    }
  }
  if (!rawRel.size) return [];
  const maxRel = Math.max(...rawRel.values()) || 1;
  const out = [];
  for (const [docIdx, rel] of rawRel) {
    const msg = messages[docIdx];
    if (!msg) continue;
    if (speaker && String(msg.name ?? '') !== String(speaker)) continue;
    if (ownerOnly && msg.owner !== true) continue;
    const text = String(msg.text ?? msg.plain ?? '').toLowerCase();
    const exact = norm.length >= 2 && text.includes(norm) ? 0.05 : 0; // 精确子串给一点点加成
    const relNorm = Math.min(1, rel / maxRel);
    const rec = recencyOf(msg, { now, halfLifeHours });
    const imp = importanceOf(msg);
    const score = w.rel * relNorm + w.imp * imp + w.rec * rec + exact;
    out.push({ index: docIdx, message: msg, score, matched: matchedByDoc.get(docIdx) ?? [] });
  }
  out.sort((a, b) => b.score - a.score);
  return out.slice(0, Math.max(1, limit));
}

/**
 * 统计型摘要（不调模型）：谁在说、热词、时段分布。
 * 「定期扫读群讨论」的零成本版本；模型版摘要属于 M3。
 */
export function digestMessages(messages, { sinceMs = 0, now = Date.now(), topTokens = 12 } = {}) {
  const list = (Array.isArray(messages) ? messages : []).filter((m) => {
    const ts = Number(m?.ts ?? m?.time ?? 0);
    return !ts || ts >= sinceMs;
  });
  const bySpeaker = new Map();
  const hours = new Array(24).fill(0);
  const tokenDf = new Map();
  for (const m of list) {
    const name = String(m.name ?? m.sender ?? '未知');
    bySpeaker.set(name, (bySpeaker.get(name) ?? 0) + 1);
    const ts = Number(m.ts ?? m.time ?? 0);
    if (ts) hours[new Date(ts).getHours()] += 1;
    for (const tok of new Set(tokenizeWords(m.text ?? m.plain ?? ''))) {
      tokenDf.set(tok, (tokenDf.get(tok) ?? 0) + 1);
    }
  }
  const speakers = [...bySpeaker.entries()]
    .sort((a, b) => b[1] - a[1])
    .slice(0, 8)
    .map(([name, count]) => ({ name, count }));
  const keywords = [...tokenDf.entries()]
    .filter(([tok]) => tok.length >= 2)
    .sort((a, b) => b[1] - a[1])
    .slice(0, topTokens)
    .map(([token, count]) => ({ token, count }));
  const busiest = hours
    .map((count, hour) => ({ hour, count }))
    .filter((h) => h.count > 0)
    .sort((a, b) => b.count - a.count)
    .slice(0, 3);
  return {
    sinceMs,
    untilMs: now,
    count: list.length,
    firstTs: list.length ? Number(list[0].ts ?? list[0].time ?? 0) : 0,
    lastTs: list.length ? Number(list[list.length - 1].ts ?? list[list.length - 1].time ?? 0) : 0,
    speakers,
    keywords,
    busiest
  };
}
