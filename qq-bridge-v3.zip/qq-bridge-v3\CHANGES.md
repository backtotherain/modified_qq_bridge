# 这份源码相对上游 v0.2.1-r1 改了什么

> 上游：`Derpyu520/qq-bridge` v0.2.1-r1（MIT）
> 本包：在其基础上新增**长时记忆、按人拉黑、主人立场与口癖、空闲时段调度**四块能力，其余逻辑（唤醒调度、未读水位、安全守卫、会话生命周期）保持原样。
> 验证环境：DSH 0.2.0-rc.2 + SnowLuma 1.14.20 + Node 22/25。`npm run test:audit` → **38/40 通过**（2 项为上游既有的环境性失败，见 §6）。

---

## 1. 文件清单（相对上游的新增/修改）

### 新增：运行时模块（902 行）

| 文件 | 行数 | 职责 |
| --- | --- | --- |
| `src/engine/memory/store.js` | 367 | append-only JSONL 记忆库（`state/memory/<key>/messages.jsonl`）+ 召回强度旁路（`recall.json`）+ 主人语料接口 + 保留期裁剪 |
| `src/engine/memory/index.js` | 239 | 中文 bigram 倒排索引 + 三要素打分（相关性/重要性/新近度）+ 遗忘曲线 + 群情统计 |
| `src/engine/memory/recall.js` | 91 | 检索结果的紧凑呈现（默认 6 条 / 1,200 字符上限） |
| `src/engine/persona/owner-style.js` | 171 | 从主人语料统计说话风格 + 立场文案 + 画像增量融合 |
| `src/engine/schedule/offpeak.js` | 34 | 空闲时段闸门（复用 `src/model-prices.js` 的 `isPeakAt`，不重复实现节假日/时区） |

### 新增：离线回归（591 行，97 项断言）

| 文件 | 断言 | 覆盖 |
| --- | --- | --- |
| `scripts/test-memory-recall.mjs` | 56 | 分词、排序、复习效应、强度跨进程恢复、主人语料隔离、去重、落盘、裁剪、体积上限、路径穿越拒绝 |
| `scripts/test-ignore-speakers.mjs` | 12 | 拉黑不唤醒但入库、不消耗 bootstrap、拍一拍不能绕过、通配与按群并集、配置热读 |
| `scripts/test-owner-style.mjs` | 13 | 风格统计、体积上限、特征不足不注入、立场文案、增量融合、重算时机、昵称排除、长名字截断 |
| `scripts/test-loyalty.mjs` | 9 | `ownerMention` 触发、限流（按会话独立）、无关谩骂不触发、开关、注入内容 |
| `scripts/test-offpeak.mjs` | 7 | 峰谷判定与价目表同源、周末、等待时间、闸门三态、异常退化 |

### 修改

| 文件 | 改动量 | 内容 |
| --- | --- | --- |
| `src/bridge.js` | +321 / -2 | 接线：记忆落盘与两个只读路由、拉黑闸门、立场/风格注入、`ownerMention` 唤醒与限流、后台作业闸门 |
| `src/mcp-snowluma-safe.js` | +47 | 注册 `qq_recall` / `qq_digest`（走 `socialV2.tools` 开关，关掉则**不注册**、不占 token） |
| `scripts/audit-bridge-harness.mjs` | +14 / -1 | 把新模块注入 vm 沙箱，并暴露新函数供测试断言 |
| `scripts/test-audit.mjs` | +9 | 5 个新测试纳入总回归 |
| `config.example.json` | +32 | 新增 `socialV3`（memory / persona）与 `socialV2.ignore`、`tools.recall/digest` 默认值 |
| `README.md` | +5 | 三段功能说明 |

---

## 2. 四块能力

### 2.1 长时记忆（默认开启）

- 原版只在内存留最近 100 条、正文截到 200 字，重启即丢。
- 现在每条消息追加写盘（保留 90 天、正文 2,000 字），agent 可用：
  - `qq_recall(query, limit, sinceMin, speaker)` —— 关键词召回旧消息，只回 6 条 / ≤1,200 字符，带 `seq` 便于用 `qq_get_message_detail` 取原文；
  - `qq_digest(sinceMin)` —— 零模型成本的群情统计（谁在说 / 高频词 / 最热闹时段）。
- 检索打分抄自两份公开研究（公式自行实现，未搬运代码）：
  - **Generative Agents**（Park et al., 2023）：`score = 0.5·相关性 + 0.3·重要性 + 0.2·新近度`；
  - **MemoryBank**（Zhong et al., 2023）：保留率 `R = 2^(-Δt / (半衰期 × S))`，每被召回一次 `S += 1`（上限 10）。
- 重要性为启发式打分（长句 / 含疑问 / 带 @ / 主人发言 ⇒ 更高），**0 次 API 调用**。

### 2.2 按人拉黑（群聊）

```json
"socialV2": {
  "ignore": {
    "speakersByGroup": {
      "*": ["<QQ号>"],
      "123456789": ["<QQ号>"]
    }
  }
}
```

- **硬闸门**：名单内的人发消息、@ 机器人、拍一拍都不会唤醒（拍一拍专门堵过）。
- 消息**仍然入库**（上下文与长时记忆保持完整）；名单内的人不会消耗 `bootstrap` 引导回合。
- 该字段**热读**：改完 `config.json` 下一条消息即生效，无需重启。
- 只对群聊生效；屏蔽整个私聊用 `deny.private`。

### 2.3 主人立场与口癖

- 唤醒包固定注入两行（合计约 250 字符）：
  - `【立场】`：默认站主人这边，但不编造事实（可以转移话题/打趣化解）；`loyalty.mode` 可选 `support`（默认）/`naive`。
  - `【说话风格】`：从主人在该会话的发言统计——句长中位数、语气词、感叹号/省略号/波浪号习惯、反问率、**只在主人高频出现的口头禅**；样本 <6 条不注入，纯本地统计。
- 有人**点名或暗讽主人**时，用独立唤醒原因 `ownerMention` 主动介入，默认 10 分钟限流 1 次（该原因会实际花钱，故设闸门）。

### 2.4 空闲时段调度

- 黑话学习等「不急着做」的后台作业先过 `engine/schedule/offpeak.js`：落在价目表峰值时段（工作日 9–12 / 14–18，单价 ×2）就推迟并打日志，等空闲时段再跑。
- 开关：`slang.offPeakOnly: false` 可关闭。

---

## 3. 成本影响（实测）

在 2.36 小时的真实运行里：

| 项 | 数值 |
| --- | --- |
| 模型调用 / 总花费 | 76 次 / ¥0.4461（≈¥0.189/小时，且**全程处于峰值价**） |
| 平均每次唤醒 | **15.5 次模型调用**（区间 4–32） |
| 相对上游预计节省 | **7% ~ 25%**，主要来自后台作业改走空闲时段 |
| 新增固定开销 | 工具面 +972 字符（可关）、每轮注入 +约 250 字符 |
| 新增 API 调用 | 记忆与画像均为**纯本地计算，0 次调用**；仅 `qq_recall` 使用时各算一次工具往返 |

> 结论写在这里以免误解：**这次改造的主要收益是能力（记得住、查得到、有立场、能拉黑），不是省钱。** 真正的成本大头是「每次唤醒 15.5 次调用」和「跑在高峰时段」，两者都与本改造正交。

---

## 4. 安装与验证

```bash
npm install                 # 会执行 postinstall 修补 @snowluma/sdk
cp config.example.json config.json   # Windows: copy config.example.json config.json
node scripts/setup-dsh.mjs <profile>  # 安装 agent preset + 挂 MCP，之后重启 DSH
npm start                   # 或双击 start.bat（守护模式）
```

离线验证（**装完依赖后**）：

```bash
npm run test:audit          # 37 个脚本的总回归
node scripts/test-memory-recall.mjs
node scripts/test-owner-style.mjs
node scripts/test-offpeak.mjs
```

其中 `test-memory-recall` / `test-owner-style` / `test-offpeak` 只依赖 `src/engine/` 与 `model-prices.js`，`npm install` 之前也能跑。

---

## 5. 本包**不包含**什么

为保护隐私与体积，以下内容被刻意排除：

- `config.json`（真实配置：含管理员 QQ、白名单、OneBot token）——只提供 `config.example.json`；
- `state/`（会话映射、未读水位、记忆库、token 账本、各类日志）；
- `node_modules/`、`.git/`、`*.log`。

`state/` 与 `config.json` 在上游 `.gitignore` 里本来就是排除项，本包与之一致。

---

## 6. 已知问题

**上游既有**、与本改造无关的两项回归失败（本机打包环境所致）：

- `test-voice-system.mjs`：依赖 `docs/guides/VOICE.md`，该文件在上游 `.gitignore` 中被排除，仓库里本就没有；
- `test-preset-local-tools.mjs`：需要读取 Electron 打包后的 `node_modules`（`@deepseek-ai/*` 位于 `app.asar` 内），打包形态读不到。

**本改造内的已知边界**：

1. 只有 `reserved2`（二代仿真）模式的消息进入长时记忆；
2. 内存缓存默认 8,000 条，更早的原文在磁盘上但**不参与检索**（冷存储检索未实现）；
3. 中文 bigram 对「同义不同词」无能为力（「降噪耳机」≠「隔音好的耳机」）；
4. 「被别人唤醒时回头回复被拉黑者」只有提示词层面的软约束，没有发送前的硬拦截（发送内容无法可靠归属到具体人）；
5. 风格画像是统计式，抓不住「语气」；模型版提炼（每 24h、走空闲时段）尚未实现，融合接口 `mergeStyle()` 已就位。

---

## 7. 设计文档

`docs/design/MEMORY_M1.md` 是长时记忆（M1）的设计说明。上游把 `docs/design/` 列入 `.gitignore` 作为内部文档，本包按「说明随包」的约定一并提供；如不需要可直接删除该目录，不影响运行。

---

## 8. 许可

上游为 MIT（见 `LICENSE`）。本改造为派生工作，遵循同一许可。所引用的两篇论文（Generative Agents / MemoryBank）仅借鉴**公式与数据流**，未搬运其代码。
