// 空闲时段闸门回归：峰谷判定必须和价目表一致（同一份 isPeakAt，避免两份判断漂移）。
// 用法：node scripts/test-offpeak.mjs
import assert from 'node:assert/strict';
import { isOffPeakAt, msUntilOffPeak, offPeakGate } from '../src/engine/schedule/offpeak.js';
import { isPeakAt, DEFAULT_PRICE_TABLE } from '../src/model-prices.js';

let failed = 0;
const check = (name, fn) => {
  try { fn(); console.log(`✅ ${name}`); } catch (error) { failed += 1; console.log(`❌ ${name} — ${error?.message ?? error}`); }
};

// 找一个「既不是周末也不是法定节假日」的周一，避免撞上内置节假日表
function findWorkMonday(startYear = 2026) {
  const holidays = new Set(DEFAULT_PRICE_TABLE.holidays ?? []);
  for (let d = 0; d < 400; d += 1) {
    const t = Date.UTC(startYear, 10, 1) + d * 86400000; // 从 11 月起找
    const date = new Date(t);
    if (date.getUTCDay() !== 1) continue; // 周一
    const ymd = `${date.getUTCFullYear()}-${String(date.getUTCMonth() + 1).padStart(2, '0')}-${String(date.getUTCDate()).padStart(2, '0')}`;
    if (holidays.has(ymd)) continue;
    return { utcMidnight: t, ymd };
  }
  throw new Error('找不到合适的周一');
}

const { utcMidnight, ymd } = findWorkMonday();
const beijing = (hour) => utcMidnight + (hour - 8) * 3600000; // 北京时间 hour 点 → UTC
const peakTime = beijing(10);   // 北京时间 10:00，峰段 9-12
const offTime = beijing(22);    // 北京时间 22:00，空闲

check('峰谷判定与 model-prices 一致', () => {
  assert.equal(isPeakAt(peakTime), true, `${ymd} 10:00 应判为峰值`);
  assert.equal(isOffPeakAt(peakTime), false);
  assert.equal(isPeakAt(offTime), false);
  assert.equal(isOffPeakAt(offTime), true);
});

check('周末不算峰值', () => {
  const sunday = utcMidnight + 6 * 86400000;
  assert.equal(isPeakAt(sunday + 2 * 3600000), false, '周日 10:00 不该是峰值');
  assert.equal(isOffPeakAt(sunday + 2 * 3600000), true);
});

check('峰段内能算出到空闲窗口的等待时间', () => {
  const wait = msUntilOffPeak(peakTime);
  assert.ok(wait > 0 && wait <= 12 * 3600000, `wait=${wait}`);
  assert.equal(isOffPeakAt(peakTime + wait), true, '等完之后应当已在空闲段');
});

check('空闲时等待为 0', () => {
  assert.equal(msUntilOffPeak(offTime), 0);
});

check('闸门：峰值拦下、空闲放行、allowPeak 覆盖', () => {
  const blocked = offPeakGate({ now: peakTime });
  assert.equal(blocked.allowed, false);
  assert.ok(blocked.reason.startsWith('peak('), blocked.reason);
  assert.ok(blocked.waitMs > 0);

  const allowed = offPeakGate({ now: offTime });
  assert.equal(allowed.allowed, true);
  assert.equal(allowed.waitMs, 0);

  const forced = offPeakGate({ now: peakTime, allowPeak: true });
  assert.equal(forced.allowed, true);
  assert.equal(forced.reason, 'allowPeak');
});

check('价目表异常时退化为放行（不能把后台作业永久卡死）', () => {
  const broken = { peakWeekdays: null, peakWindows: null, holidays: [] };
  assert.equal(offPeakGate({ now: peakTime, table: broken }).allowed, true);
});

console.log(failed ? `\n❌ ${failed} 项失败` : '\n✅ 空闲时段闸门全部通过');
process.exit(failed ? 1 : 0);
