// 空闲时段调度：把「不急着做」的后台作业挪到 DeepSeek 的空闲价时段。
//
// 依据是仓库自己的价目表（src/model-prices.js）：工作日 9:00-12:00 / 14:00-18:00
// 是峰值，单价 ×2；其余时间半价。所以同样的作业，夜里跑就是省一半。
// 这里不重复实现节假日/时区逻辑，直接复用 isPeakAt()，避免两份判断漂移。
import { isPeakAt, resolvePriceTable, beijingParts } from '../../model-prices.js';

const STEP_MS = 15 * 60 * 1000;
const MAX_LOOKAHEAD_MS = 48 * 60 * 60 * 1000;

/** 现在是否空闲价(或定价关掉了峰谷)。 */
export function isOffPeakAt(atMs = Date.now(), table) {
  const t = table ?? resolvePriceTable();
  try {
    return !isPeakAt(atMs, t);
  } catch {
    // 价目表异常时按"空闲"处理：宁可现在跑，也不要因为调度器坏了永久不跑
    return true;
  }
}

/** 距离下一个空闲窗口还有多久（毫秒）。已经在空闲窗口内返回 0。 */
export function msUntilOffPeak(atMs = Date.now(), table) {
  const t = table ?? resolvePriceTable();
  if (isOffPeakAt(atMs, t)) return 0;
  for (let offset = STEP_MS; offset <= MAX_LOOKAHEAD_MS; offset += STEP_MS) {
    if (isOffPeakAt(atMs + offset, t)) return offset;
  }
  return MAX_LOOKAHEAD_MS;
}

/**
 * 后台作业的放行判断。
 * @returns {{allowed:boolean, waitMs:number, reason:string}}
 */
export function offPeakGate({ now = Date.now(), table, allowPeak = false } = {}) {
  const t = table ?? resolvePriceTable();
  if (allowPeak) return { allowed: true, waitMs: 0, reason: 'allowPeak' };
  if (isOffPeakAt(now, t)) return { allowed: true, waitMs: 0, reason: 'off-peak' };
  const waitMs = msUntilOffPeak(now, t);
  const { hour } = beijingParts(now);
  return { allowed: false, waitMs, reason: `peak(${hour}时)` };
}
