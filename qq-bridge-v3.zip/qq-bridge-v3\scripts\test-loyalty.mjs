// 立场 + 风格注入的回归（跑真实 bridge 代码，vm 沙箱，不连 QQ / DSH）。
// 关注三件事：会不会在该出手时出手（ownerMention）、会不会乱花钱（限流）、
// 提示词里到底加了什么（体积与内容）。
// 用法：node scripts/test-loyalty.mjs
import assert from 'node:assert/strict';
import { bridgeHarness } from './audit-bridge-harness.mjs';

let failed = 0;
const check = async (name, fn) => {
  try { await fn(); console.log(`✅ ${name}`); } catch (error) { failed += 1; console.log(`❌ ${name} — ${error?.message ?? error}`); }
};

const GROUP = '456';
const GROUP2 = '457';
const OWNER = '123';
const OWNER_NICK = '老白';

const mkHarness = (extra = {}) => bridgeHarness({
  config: {
    ownerQQ: OWNER,
    allow: { private: [OWNER], groups: [GROUP, GROUP2] },
    ...extra
  }
});

/** 往会话里灌主人的话（isOwner=true 走 owner 标记），制造风格样本。 */
function seedOwner(h, key, count = 8) {
  const lines = ['就这', '行吧呗', '那我先看看啊', '就这吧', '你俩商量呗', '别急呗', '行吧行吧呗', '我看看啊'];
  for (let i = 0; i < count; i += 1) {
    const text = lines[i % lines.length];
    h.appendSocialV2Message(key, OWNER_NICK, text, text, false, true, 100 + i, [], OWNER);
  }
}

function seedPeers(h, key) {
  const peers = [
    '我觉得这个方案需要从整体架构上再考虑一下！',
    '咱们是不是应该先对齐接口再动手！',
    '这个堆栈信息里写的是空指针异常！'
  ];
  peers.forEach((text, i) => {
    h.appendSocialV2Message(key, '群友甲', text, text, false, false, 200 + i, [], '777');
  });
}

const groupEvent = (userId, text) => ({
  self_id: 111,
  user_id: Number(userId),
  group_id: Number(GROUP),
  message_id: 900,
  sender: { user_id: Number(userId), nickname: '群友甲', card: '' },
  message: [{ type: 'text', data: { text } }]
});

await check('有人在群里点主人名字并贬低 ⇒ 触发 ownerMention', async () => {
  const h = await mkHarness();
  h.setMode('reserved2');
  seedOwner(h, `group:${GROUP}`);
  seedPeers(h, `group:${GROUP}`);
  const st = h.getSocialV2State(`group:${GROUP}`);
  const text = `${OWNER_NICK}就这水平？也太菜了吧`;
  const reason = h.evaluateWakeTriggerV2(`group:${GROUP}`, st, groupEvent(777, text), 'group', text, text, false);
  assert.equal(reason, 'ownerMention', `实际=${reason}`);
  await h.close();
});

await check('同一个群 10 分钟内只许触发一次（这个原因会真花钱）', async () => {
  const h = await mkHarness();
  h.setMode('reserved2');
  seedOwner(h, `group:${GROUP}`);
  const st = h.getSocialV2State(`group:${GROUP}`);
  const text = `${OWNER_NICK}真不行，垃圾`;
  const first = h.evaluateWakeTriggerV2(`group:${GROUP}`, st, groupEvent(777, text), 'group', text, text, false);
  const second = h.evaluateWakeTriggerV2(`group:${GROUP}`, st, groupEvent(778, text), 'group', text, text, false);
  assert.equal(first, 'ownerMention');
  assert.equal(second, null, '第二次必须被限流挡掉');
  await h.close();
});

await check('另一个群有自己的一份额度', async () => {
  const h = await mkHarness();
  h.setMode('reserved2');
  seedOwner(h, `group:${GROUP}`);
  seedOwner(h, `group:${GROUP2}`);
  const text = `${OWNER_NICK}太菜了`;
  const a = h.evaluateWakeTriggerV2(`group:${GROUP}`, h.getSocialV2State(`group:${GROUP}`), groupEvent(777, text), 'group', text, text, false);
  const b = h.evaluateWakeTriggerV2(`group:${GROUP2}`, h.getSocialV2State(`group:${GROUP2}`), groupEvent(777, text), 'group', text, text, false);
  assert.equal(a, 'ownerMention');
  assert.equal(b, 'ownerMention', '限流是按会话算的');
  await h.close();
});

await check('骂别的东西不触发（不related主人）', async () => {
  const h = await mkHarness();
  h.setMode('reserved2');
  seedOwner(h, `group:${GROUP}`);
  const st = h.getSocialV2State(`group:${GROUP}`);
  const text = '这游戏太菜了，策划垃圾';
  const reason = h.evaluateWakeTriggerV2(`group:${GROUP}`, st, groupEvent(777, text), 'group', text, text, false);
  assert.equal(reason, null, `实际=${reason}`);
  await h.close();
});

await check('关掉开关就不介入', async () => {
  const h = await mkHarness({ socialV3: { persona: { loyalty: { enabled: false } } } });
  h.setMode('reserved2');
  seedOwner(h, `group:${GROUP}`);
  const st = h.getSocialV2State(`group:${GROUP}`);
  const text = `${OWNER_NICK}太菜了`;
  const reason = h.evaluateWakeTriggerV2(`group:${GROUP}`, st, groupEvent(777, text), 'group', text, text, false);
  assert.equal(reason, null);
  await h.close();
});

await check('唤醒包里出现【立场】和【说话风格】', async () => {
  const h = await mkHarness();
  h.setMode('reserved2');
  seedOwner(h, `group:${GROUP}`, 8);
  seedPeers(h, `group:${GROUP}`);
  const prompt = h.buildWakePromptV2(`group:${GROUP}`, 'bootstrap');
  assert.match(prompt, /【立场】/, '立场必须在场');
  assert.match(prompt, new RegExp(OWNER), '立场里要点出主人是谁');
  assert.match(prompt, /【说话风格】/, `风格行缺失：${prompt.slice(0, 200)}`);
  await h.close();
});

await check('风格行体积受配置约束', async () => {
  const h = await mkHarness({ socialV3: { persona: { style: { maxChars: 40 } } } });
  h.setMode('reserved2');
  seedOwner(h, `group:${GROUP}`, 8);
  const line = h.ownerStyleLine(`group:${GROUP}`);
  assert.ok(line.length <= 40, `len=${line.length}`);
  await h.close();
});

await check('主人样本不足时不硬编造风格', async () => {
  const h = await mkHarness();
  h.setMode('reserved2');
  seedOwner(h, `group:${GROUP}`, 2);
  assert.equal(h.ownerStyleLine(`group:${GROUP}`), '', '样本 < minSamples 就不注入');
  const prompt = h.buildWakePromptV2(`group:${GROUP}`, 'bootstrap');
  assert.ok(!prompt.includes('【说话风格】'));
  await h.close();
});

console.log(failed ? `\n❌ ${failed} 项失败` : '\n✅ 立场与风格注入全部通过');
process.exit(failed ? 1 : 0);
