// 记忆检索的「给模型看的形状」层：把命中结果压成紧凑文本。
//
// 这里是省 token 的关键一环：检索结果直接进对话上下文，所以必须
//   · 行数有上限（默认 6 条）、总字符有上限（默认 1200 字）；
//   · 每条只给「seq + 时间 + 谁 + 截断正文」，正文默认截到 90 字；
//   · 带上 seq，让模型需要全文时用 qq_get_message_detail 精确取，而不是让这里全塞。
// 体积上限由调用方（bridge 的路由）从 config 传入，默认值仅作兜底。

const DEFAULT_MAX_CHARS = 1200;
const DEFAULT_LIMIT = 6;
const SNIPPET_CHARS = 90;

function pad2(n) {
  return String(n).padStart(2, '0');
}

/** 把毫秒时间戳格式化成 `MM-DD HH:mm`（群聊检索里不需要年份，省字符）。 */
export function shortTime(ts) {
  const n = Number(ts);
  if (!Number.isFinite(n) || n <= 0) return '';
  const d = new Date(n);
  return `${pad2(d.getMonth() + 1)}-${pad2(d.getDate())} ${pad2(d.getHours())}:${pad2(d.getMinutes())}`;
}

/** 截断时保留句子边界，避免把半句话喂给模型让它误读。 */
function snippet(text, max = SNIPPET_CHARS) {
  const s = String(text ?? '').replace(/\s+/g, ' ').trim();
  if (s.length <= max) return s;
  const head = s.slice(0, max);
  const cut = Math.max(head.lastIndexOf('，'), head.lastIndexOf('。'), head.lastIndexOf('；'), head.lastIndexOf(' '));
  return `${cut > max * 0.5 ? head.slice(0, cut) : head}…`;
}

/**
 * 把 store.search() 的结果格式化成一段给模型读的文本。
 *
 * @param {{key:string, query:string, hits:Array<{message:object, score:number, matched:string[]}>, limit?:number, maxChars?:number, now?:number}} p
 * @returns {{text:string, shown:number, truncated:boolean}}
 */
export function formatRecall({ key, query, hits, limit = DEFAULT_LIMIT, maxChars = DEFAULT_MAX_CHARS, now = Date.now() }) {
  const list = Array.isArray(hits) ? hits.slice(0, Math.max(1, limit)) : [];
  if (!list.length) {
    return {
      text: `【回忆 ${key}】查「${query}」没有命中。可以换更短的关键词（人名/物品名/梗），或让人先说说是什么事。`,
      shown: 0,
      truncated: false
    };
  }
  const head = `【回忆 ${key}】查「${query}」命中 ${hits.length} 条（按相关度，旧消息也会召回）`;
  const lines = [];
  let total = head.length;
  let truncated = false;
  for (const hit of list) {
    const msg = hit?.message ?? {};
    const line = `#${msg.seq ?? '?'} ${shortTime(msg.ts)} ${msg.self ? '我' : (msg.name || '未知')}：${snippet(msg.text)}`;
    if (total + line.length + 1 > maxChars) { truncated = true; break; }
    lines.push(line);
    total += line.length + 1;
  }
  const tail = truncated ? `（还有 ${hits.length - lines.length} 条未展示；换更具体的关键词或传 limit）` : '';
  return { text: [head, ...lines, tail].filter(Boolean).join('\n'), shown: lines.length, truncated };
}

/**
 * 把 store.digest() 的结果格式化成一段短文本：谁在说、热词、什么时候最热闹。
 * 这是「我不在的时候群里聊了啥」的零成本回答，不产生任何模型调用。
 */
export function formatDigest({ key, digest, sinceMinutes = 60 }) {
  if (!digest || !digest.count) {
    return `【群情 ${key}】最近 ${sinceMinutes} 分钟没有消息。`;
  }
  const speakers = (digest.speakers ?? []).slice(0, 5)
    .map((s) => `${s.name}(${s.count})`)
    .join(' ');
  const keywords = (digest.keywords ?? []).slice(0, 10).map((k) => k.token).join(' ');
  const busiest = (digest.busiest ?? []).map((h) => `${h.hour}时×${h.count}`).join(' ');
  const lines = [
    `【群情 ${key}】最近 ${sinceMinutes} 分钟共 ${digest.count} 条`,
    speakers ? `说话的人：${speakers}` : '',
    keywords ? `高频词：${keywords}` : '',
    busiest ? `最热闹：${busiest}` : '',
    '要具体内容用 qq_recall(query=…)，要看原文用 qq_get_recent_messages。'
  ];
  return lines.filter(Boolean).join('\n');
}

/** 检索参数归一化：MCP 传进来的都是字符串/数字混着，统一成安全值。 */
export function normalizeRecallOptions(raw = {}, defaults = {}) {
  const limit = Math.min(
    defaults.maxLimit ?? 20,
    Math.max(1, Number(raw.limit) || defaults.limit || DEFAULT_LIMIT)
  );
  const maxChars = Math.min(
    defaults.maxChars ?? DEFAULT_MAX_CHARS,
    Math.max(200, Number(raw.maxChars) || defaults.maxChars || DEFAULT_MAX_CHARS)
  );
  const sinceMin = Math.max(0, Number(raw.sinceMin) || 0);
  return {
    limit,
    maxChars,
    query: String(raw.query ?? '').trim(),
    speaker: String(raw.speaker ?? '').trim(),
    sinceMs: sinceMin ? Date.now() - sinceMin * 60000 : 0
  };
}
