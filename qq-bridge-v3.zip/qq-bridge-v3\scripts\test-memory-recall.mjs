// 长时记忆（M1）离线回归：分词 / 倒排 / 检索 / 去重 / 落盘 / 裁剪。
// 不依赖 SnowLuma、DSH、QQ，也不调模型。
// 用法：node scripts/test-memory-recall.mjs
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { tokenize, tokenizeQuery, tokenizeWords, buildIndex, searchIndex } from '../src/engine/memory/index.js';
import { createMemoryStore, safeKey } from '../src/engine/memory/store.js';
import { formatRecall, formatDigest, normalizeRecallOptions } from '../src/engine/memory/recall.js';

let failed = 0;
const assert = (name, cond, extra = '') => {
  if (!cond) failed += 1;
  console.log(`${cond ? '✅' : '❌'} ${name}${extra ? ' — ' + extra : ''}`);
};

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'qq-memory-test-'));
const DAY = 86400000;
const now = Date.now();

// ── 1. 分词 ──────────────────────────────────────────────────────────────
{
  const t = tokenize('赛博朋克新DLC');
  assert('中文切出 bigram', t.includes('赛博') && t.includes('博朋') && t.includes('朋克'), t.join('/'));
  assert('中文整串也保留', tokenize('赛博朋克').includes('赛博朋克'));
  assert('拉丁词小写归一', t.includes('dlc'));
  assert('单字查询可召回', tokenizeQuery('贵').includes('贵'));
  assert('标点不产生空 token', !tokenize('，。！').some((x) => x.trim() === ''));
  {
    // 群情摘要用的是「词形」分词：不能把 bigram 碎片混进高频词列表
    const w = tokenizeWords('降噪耳机，通勤真香');
    assert('digest 词形分词出连续串', w.includes('降噪耳机') && w.includes('通勤真香'), w.join('/'));
    assert('digest 词形分词不出 bigram 碎片', !w.includes('降噪') && !w.includes('噪耳'), w.join('/'));
  }
}

// ── 2. 倒排 + 打分 ────────────────────────────────────────────────────────
{
  const msgs = [
    { seq: 1, ts: now - 30 * DAY, name: '老张', text: '那个索尼的降噪耳机现在多少钱' },
    { seq: 2, ts: now - 2 * DAY, name: '小明', text: '听说新出的耳机续航很差' },
    { seq: 3, ts: now - DAY, name: '老张', text: '赛博朋克的新DLC好像打折了' }
  ];
  const idx = buildIndex(msgs);
  const hits = searchIndex(idx, msgs, '耳机', { limit: 5, now });
  assert('关键词命中 2 条', hits.length === 2, `实际 ${hits.length}`);
  assert('越新的越靠前（时间衰减生效）', hits[0].message.seq === 2, `top=${hits[0].message.seq}`);
  const bySpeaker = searchIndex(idx, msgs, '耳机', { limit: 5, now, speaker: '老张' });
  assert('说话人过滤生效', bySpeaker.length === 1 && bySpeaker[0].message.seq === 1);
  const recentOnly = searchIndex(idx, msgs, '耳机', { limit: 5, now, sinceMs: now - 3 * DAY });
  assert('时间窗过滤生效', recentOnly.length === 1 && recentOnly[0].message.seq === 2);
  assert('查不到时返回空数组', searchIndex(idx, msgs, '完全不相关的词', { now }).length === 0);
}

// ── 3. store：写入 / 去重 / 落盘 ──────────────────────────────────────────
{
  const dir = path.join(tmp, 'store1');
  const store = createMemoryStore({ dir, retentionDays: 90, maxCacheMessages: 100 });
  const key = 'group:123456';
  assert('合法 key 通过', safeKey(key) === key);
  assert('路径穿越 key 被拒', safeKey('group:../../x') === null && safeKey('group:1/2') === null);

  const a = store.append(key, { seq: 1, messageId: 'm-1', time: now - 3600000, sender: '小明', text: '我买了那个索尼耳机' });
  const dupId = store.append(key, { seq: 1, messageId: 'm-1', time: now - 3600000, sender: '小明', text: '我买了那个索尼耳机' });
  const dupSeq = store.append(key, { seq: 1, messageId: 'm-2', time: now, sender: '小明', text: '重复 seq' });
  const empty = store.append(key, { seq: 2, text: '   ' });
  assert('首次写入成功', a.added === true);
  assert('重复 messageId 被去重', dupId.added === false && dupId.reason === 'dup-id');
  assert('重复 seq 被去重', dupSeq.added === false && dupSeq.reason === 'dup-seq');
  assert('空文本不入库', empty.added === false);

  store.append(key, { seq: 2, messageId: 'm-3', time: now - 1800000, sender: '老张', text: '那个耳机双十一便宜三百' });
  const hits = store.search(key, '索尼');
  assert('检索命中', hits.length === 1 && hits[0].message.seq === 1);

  // 落盘：新实例读同一个目录
  const store2 = createMemoryStore({ dir, retentionDays: 90 });
  const hits2 = store2.search(key, '耳机');
  assert('重启后记忆仍在（读盘）', hits2.length === 2, `实际 ${hits2.length}`);
  assert('重启后去重集合正确（不会重复写入）', store2.append(key, { seq: 1, messageId: 'm-1', text: '重复' }).added === false);

  const stats = store2.stats(key);
  assert('stats 行数与缓存一致', stats.lines >= 2 && stats.cached === 2, JSON.stringify(stats));
  assert('索引大小与消息数一致', stats.indexTokens > 0);
}

// ── 4. 增量索引与批量淘汰后的索引一致性 ──────────────────────────────────
{
  const dir = path.join(tmp, 'store2');
  const store = createMemoryStore({ dir, maxCacheMessages: 50 });
  const key = 'group:999';
  for (let i = 1; i <= 600; i += 1) {
    store.append(key, { seq: i, messageId: `b-${i}`, time: now - (600 - i) * 60000, sender: i % 2 ? '甲' : '乙', text: `第${i}条 关于${i % 7 === 0 ? '显卡' : '午饭'}的讨论` });
  }
  const st = store.stats(key);
  assert('超出 maxCacheMessages 后缓存被裁到上限', st.cached === 50, `cached=${st.cached}`);
  assert('磁盘行数仍保留全部', st.lines === 600, `lines=${st.lines}`);
  const hit = store.search(key, '显卡', { limit: 3 });
  // 缓存只留最后 50 条（seq 551..600），550..600 里 553/560/.../595 是显卡
  assert('淘汰后检索仍只返回缓存内的命中', hit.length > 0 && hit.every((h) => h.message.seq > 550), hit.map((h) => h.message.seq).join(','));
}

// ── 5. 格式化：体积上限是硬约束 ──────────────────────────────────────────
{
  const dir = path.join(tmp, 'fmt');
  const store = createMemoryStore({ dir });
  const key = 'group:42';
  for (let i = 0; i < 30; i += 1) {
    store.append(key, { seq: i + 1, messageId: `f-${i}`, time: now - i * 60000, sender: '话痨', text: `耳机耳机耳机，我要说第${i}遍，这个耳机的降噪真的可以，但是价格有点贵啊兄弟` });
  }
  const hits = store.search(key, '耳机', { limit: 30 });
  const formatted = formatRecall({ key, query: '耳机', hits, limit: 6, maxChars: 400, now });
  assert('formatRecall 遵守 maxChars', formatted.text.length <= 400 + 80, `len=${formatted.text.length}`);
  assert('formatRecall 标注了省略', formatted.truncated === true || formatted.shown <= 6);
  assert('formatRecall 带 seq 便于回查原文', /#\d+/.test(formatted.text));
  const miss = formatRecall({ key, query: '不存在的东西', hits: [], now });
  assert('无命中时给出可操作提示', miss.text.includes('没有命中') && miss.shown === 0);

  const dg = store.digest(key, { sinceMs: now - DAY, now });
  const fd = formatDigest({ key, digest: dg, sinceMinutes: 1440 });
  assert('digest 统计到消息', dg.count === 30, `count=${dg.count}`);
  assert('digest 文本含高频词', fd.includes('耳机'));
  assert('digest 文本很短（不塞原文）', fd.length < 400, `len=${fd.length}`);
}

// ── 6. 参数归一化：挡住越界输入 ──────────────────────────────────────────
{
  const o = normalizeRecallOptions({ limit: 999, maxChars: 999999, sinceMin: -5, query: ' 耳机 ' }, { maxLimit: 20 });
  assert('limit 被钳到上限', o.limit === 20);
  assert('maxChars 被钳到上限', o.maxChars <= 1200);
  assert('负数 sinceMin 归零', o.sinceMs === 0);
  assert('query 去空白', o.query === '耳机');
}

// ── 7. 过期裁剪 ──────────────────────────────────────────────────────────
{
  const dir = path.join(tmp, 'prune');
  const store = createMemoryStore({ dir, retentionDays: 30 });
  const key = 'group:7';
  store.append(key, { seq: 1, messageId: 'old-1', time: now - 60 * DAY, sender: '甲', text: '两个月前的旧事' });
  store.append(key, { seq: 2, messageId: 'new-1', time: now - DAY, sender: '乙', text: '昨天的事' });
  const r = store.prune(key, now);
  assert('裁剪删掉了过期消息', r.pruned === 1, JSON.stringify(r));
  const store2 = createMemoryStore({ dir, retentionDays: 30 });
  assert('裁剪后旧消息不可检索', store2.search(key, '两个月前').length === 0);
  assert('裁剪后新消息仍在', store2.search(key, '昨天').length === 1);
}

// ── 8. 无写入时检索不炸 ──────────────────────────────────────────────────
{
  const store = createMemoryStore({ dir: path.join(tmp, 'empty') });
  assert('空会话检索返回空', store.search('group:1', '任意').length === 0);
  assert('空会话 digest 返回 0 条', store.digest('group:1').count === 0);
  assert('非法 key 的 append 被拒', store.append('bad:key', { text: 'x' }).added === false);
}

// ── 8. 三要素打分 + 遗忘曲线（Generative Agents / MemoryBank）──────────────
{
  const { searchIndex: searchFn, buildIndex: buildFn, recencyOf, importanceOf } = await import('../src/engine/memory/index.js');
  const nowT = Date.now();
  const msgs = [
    { seq: 1, ts: nowT - 2 * DAY, name: '甲', text: '显卡这个事我们讨论了很久', imp: 9 },
    { seq: 2, ts: nowT - 3600000, name: '乙', text: '显卡', imp: 2 }
  ];
  const idx = buildFn(msgs);
  const ranked = searchFn(idx, msgs, '显卡', { now: nowT });
  assert('重要性高的旧消息能压过重要性低的新消息', ranked[0].message.seq === 1, `top=${ranked[0].message.seq}`);

  const sameText = [
    { seq: 10, ts: nowT - 2 * DAY, name: '甲', text: '耳机', imp: 5, s: 1 },
    { seq: 11, ts: nowT - 2 * DAY, name: '乙', text: '耳机', imp: 5, s: 4 }
  ];
  const idx2 = buildFn(sameText);
  const r2 = searchFn(idx2, sameText, '耳机', { now: nowT });
  assert('同年龄下记忆强度高的更靠前（复习效应）', r2[0].message.seq === 11, `top=${r2[0].message.seq}`);
  assert('记忆强度确实抬高了保留率', recencyOf(sameText[1], { now: nowT }) > recencyOf(sameText[0], { now: nowT }));
  assert('重要性归一化到 0~1', importanceOf({ imp: 10 }) === 1 && importanceOf({}) === 0.5);
}

// ── 9. 召回会强化记忆，并且能落盘 ────────────────────────────────────────
{
  const dir = path.join(tmp, 'recall');
  const store = createMemoryStore({ dir });
  const key = 'group:88';
  store.append(key, { seq: 1, messageId: 'r1', time: now - 10 * DAY, sender: '甲', text: '那个耳机的梗' });
  const before = store.stats(key);
  assert('初始召回记录为空', before.recalled === 0);
  store.search(key, '耳机');
  const after = store.stats(key);
  assert('检索后记下了一次召回', after.recalled === 1, JSON.stringify(after));
  // 同一实例内强度 +1
  const hit1 = store.search(key, '耳机')[0];
  assert('重复检索后强度会上升', hit1.message.s >= 2, `s=${hit1.message.s}`);
  // 落盘：新实例能读回强度（召回记录是防抖写的，测试里手动 flush）
  store.flush();
  const store2 = createMemoryStore({ dir });
  const hit2 = store2.search(key, '耳机')[0];
  assert('强度可跨进程恢复', hit2.message.s >= 3, `s=${hit2.message.s}`);
}

// ── 10. 主人标记（风格学习的语料来源）─────────────────────────────────────
{
  const dir = path.join(tmp, 'owner');
  const store = createMemoryStore({ dir });
  const key = 'group:77';
  store.append(key, { seq: 1, messageId: 'o1', time: now - 60000, sender: '主人', text: '行吧，那你先弄着', owner: true });
  store.append(key, { seq: 2, messageId: 'o2', time: now - 50000, sender: '群友', text: '哦' });
  store.append(key, { seq: 0, time: now - 40000, name: '我', text: '我自己说的话', self: true });
  const owners = store.ownerSamples(key);
  assert('只有主人标记的消息进主人语料', owners.length === 1 && owners[0].text.includes('先弄着'), `len=${owners.length}`);
  assert('机器人自己的话不算主人语料（否则会学自己）', !owners.some((m) => m.text.includes('我自己说的话')));
  assert('群友语料与之互补', store.peerSamples(key).length === 2);
  assert('stats 报出主人消息数', store.stats(key).ownerCount === 1);
}

fs.rmSync(tmp, { recursive: true, force: true });
console.log(failed ? `\n❌ ${failed} 项失败` : '\n✅ 记忆检索全部通过');
process.exit(failed ? 1 : 0);
