// 主人风格画像的纯函数回归：统计口径、注入体积、立场文案、增量融合。
// 不调模型、不碰 QQ / DSH。
// 用法：node scripts/test-owner-style.mjs
import assert from 'node:assert/strict';
import {
  analyzeStyle, buildStyleLine, buildStanceLine, mergeStyle, needsRefresh
} from '../src/engine/persona/owner-style.js';

let failed = 0;
const check = (name, fn) => {
  try { fn(); console.log(`✅ ${name}`); } catch (error) { failed += 1; console.log(`❌ ${name} — ${error?.message ?? error}`); }
};

// 主人：短句、爱用「呗/啊」、几乎不用感叹号、口头禅「就这」（独立出现才算）
const owner = [
  '就这', '就这吧', '就这就这', '行吧呗', '那你先弄着呗', '我看看啊', '别急呗', '行吧行吧呗'
].map((text) => ({ text, name: '老白' }));

// 群友：长句、书面、用感叹号，但**不**用「就这」
const peers = [
  '我觉得这个问题需要从架构层面重新梳理一下！', '兄弟们这个方案我仔细看过了！',
  '咱们是不是应该先把接口对齐再动手！', '今天这个会开得我有点懵！',
  '这个报错的堆栈里说的是空指针异常！', '我建议先写测试再改代码！'
].map((text) => ({ text, name: '群友' }));

check('分析出样本数与句长', () => {
  const s = analyzeStyle(owner, peers);
  assert.equal(s.count, 8);
  assert.ok(s.medianLen > 0 && s.medianLen <= 12, `medianLen=${s.medianLen}`);
  assert.equal(s.shortRate, 1);
});

check('识别语气词', () => {
  const s = analyzeStyle(owner, peers);
  assert.ok(s.particles.includes('呗') || s.particles.includes('啊'), s.particles.join('/'));
});

check('感叹号习惯：主人几乎不用', () => {
  const s = analyzeStyle(owner, peers);
  assert.ok(s.exclamRate <= 0.02, `exclamRate=${s.exclamRate}`);
});

check('口头禅只在主人高频时才算', () => {
  const s = analyzeStyle(owner, peers);
  assert.ok(s.catchphrases.some((w) => w.includes('就这')), s.catchphrases.join('/'));
  // 群友高频、主人不用的词不该进主人画像
  assert.ok(!s.catchphrases.some((w) => w.includes('架构')), s.catchphrases.join('/'));
});

check('无样本返回 null', () => {
  assert.equal(analyzeStyle([], peers), null);
  assert.equal(analyzeStyle([{ text: '  ' }], peers), null);
});

check('注入行体积受 maxChars 约束', () => {
  const s = analyzeStyle(owner, peers);
  for (const max of [40, 80, 150]) {
    const line = buildStyleLine(s, { maxChars: max });
    assert.ok(line.length <= max, `max=${max} len=${line.length}`);
    assert.ok(line.startsWith('【说话风格】'));
  }
});

check('没有可用特征时宁可不注入', () => {
  // 句子都偏长（触发不了"句子偏短"）、只有一个感叹号（触发不了感叹号习惯）、
  // 没有语气词/反问/省略号，也没有重复到能算口癖的词
  const flat = analyzeStyle(
    ['今天下午的评审会把接口对齐的事情定下来了！', '后端那边决定先上灰度再推到全量发布',
      '监控面板这个季度加了两条新的告警规则', '灰度环境的流量已经切成一半到新集群',
      '老库的迁移脚本现在还在后台慢慢跑着', '压测结果比我们预期的要好上一些',
      '发布窗口最后定在明天凌晨那个时间段', '回滚方案也一并准备好放在同一份文档里'].map((text) => ({ text })),
    []
  );
  const line = buildStyleLine(flat);
  assert.equal(line, '', `实际: ${line}`);
});

check('立场文案：support 有底线，naive 没有', () => {
  const support = buildStanceLine({ ownerQQ: '123', ownerName: '老白', mode: 'support' });
  assert.match(support, /【立场】/);
  assert.match(support, /不能硬撒谎/);
  const naive = buildStanceLine({ ownerQQ: '123', mode: 'naive' });
  assert.match(naive, /永远站主人这边/);
  assert.ok(!naive.includes('不能硬撒谎'));
  assert.ok(buildStanceLine({}).length > 0);
});

check('机器人的昵称不算主人口头禅（真实数据踩过）', () => {
  // 主人 @ 机器人时会把昵称带进语料，不能把它学成"主人口癖"
  const nick = 'ゆきのさきだより';
  const corpus = [`@${nick} 别急`, `@${nick} 好`, `@${nick} 行`].map((text) => ({ text }));
  const withEx = analyzeStyle(corpus, [], { excludeWords: [nick] });
  assert.ok(!withEx.catchphrases.some((w) => nick.includes(w)), withEx.catchphrases.join('/'));
});

check('立场行里的群名片会被截断', () => {
  const long = '这是一个特别特别长的群名片名字呀呀呀';
  const line = buildStanceLine({ ownerQQ: '123', ownerName: long });
  assert.ok(!line.includes(long), '长名字不该整段塞进去');
  assert.ok(line.length <= 110, `len=${line.length}`);
});

check('增量融合：新观察占七成', () => {
  const a = { count: 10, medianLen: 10, exclamRate: 0.1, particles: ['呗'], catchphrases: ['就这'] };
  const b = { count: 20, medianLen: 40, exclamRate: 0.5, particles: ['啊'], catchphrases: [] };
  const m = mergeStyle(a, b, { alpha: 0.3 });
  assert.equal(m.medianLen, Math.round(10 * 0.3 + 40 * 0.7));
  assert.equal(m.particles, b.particles, '新习惯优先');
  assert.equal(m.catchphrases, a.catchphrases, '新观察没有就保留旧的');
  assert.equal(mergeStyle(null, b), b);
  assert.equal(mergeStyle(a, null), a);
});

check('重算时机：样本够 + （涨了 5 条 或 过了 6 小时）', () => {
  const now = Date.now();
  assert.equal(needsRefresh({ sampleCount: 3, minSamples: 6, now }), false, '样本不足不重算');
  assert.equal(needsRefresh({ sampleCount: 8, builtAt: 0, now }), true, '首次必算');
  assert.equal(needsRefresh({ sampleCount: 10, builtCount: 10, builtAt: now - 1000, now }), false, '刚算过且没涨');
  assert.equal(needsRefresh({ sampleCount: 15, builtCount: 10, builtAt: now - 1000, now }), true, '涨了 5 条重算');
  assert.equal(needsRefresh({ sampleCount: 10, builtCount: 10, builtAt: now - 7 * 3600 * 1000, now }), true, '超过 6 小时重算');
});

console.log(failed ? `\n❌ ${failed} 项失败` : '\n✅ 风格画像全部通过');
process.exit(failed ? 1 : 0);
