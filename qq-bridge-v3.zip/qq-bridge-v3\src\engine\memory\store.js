// 长时记忆的存储层：每个 QQ 会话一份 append-only JSONL + 一份召回记录。
//
// 设计取舍（M1 阶段刻意保守）：
//   · 只用文件，不引 SQLite：零依赖、可手工 tail、崩溃后最多丢最后一行；
//   · 内存里只留最近 maxCacheMessages 条（默认 8000）与它们的倒排索引，
//     更早的原文还在磁盘上，但**不参与检索**——冷存储检索留给 M2；
//   · 追加即增量更新索引（addDocument），不重建；
//   · 「召回强度」单独存 recall.json（seq → {s, at}）：JSONL 是 append-only，
//     不能为了记一次召回就整份重写（那张表会越来越大）。
//
// 安全边界：
//   · key 必须是 group:<数字> / private:<数字>，其它一律拒绝（防路径穿越）；
//   · 文件名用下划线拼，不保留冒号。
import fs from 'node:fs';
import path from 'node:path';
import { buildIndex, addDocument, searchIndex, digestMessages, DEFAULT_IMPORTANCE } from './index.js';

const SAFE_KEY = /^(group|private):(\d{1,20})$/;
const DAY_MS = 86400000;
const TAIL_BYTES = 4 * 1024 * 1024;
const RECALL_SAVE_DEBOUNCE_MS = 3000;

/** 校验并规范化会话 key。非法返回 null。 */
export function safeKey(key) {
  const raw = String(key ?? '').trim();
  const m = SAFE_KEY.exec(raw);
  if (!m) return null;
  return `${m[1]}:${m[2]}`;
}

function dirName(key) {
  const safe = safeKey(key);
  if (!safe) return null;
  return safe.replace(':', '_');
}

/**
 * 重要性启发式（1~10）：不调模型也能给出一个像样的初值。
 * 群聊里「重要」≈ 信息量：长句/带问号/被 @/是主人的话 → 更重要；
 * 「草」「哈哈」这类纯语气 → 不重要。后续整理作业可以用模型覆盖它。
 */
export function heuristicImportance(text, { owner = false } = {}) {
  const s = String(text ?? '').trim();
  let score = DEFAULT_IMPORTANCE;
  if (s.length <= 4) score -= 2;
  else if (s.length >= 60) score += 1;
  if (/[?？]|吗|怎么|为什么|多少|哪[个里]/.test(s)) score += 1;
  if (/@/.test(s)) score += 1;
  if (owner) score += 1;
  return Math.min(10, Math.max(1, score));
}

/**
 * @param {{dir:string, retentionDays?:number, maxCacheMessages?:number, maxTextChars?:number, logger?:Function}} opts
 */
export function createMemoryStore({
  dir, retentionDays = 90, maxCacheMessages = 8000, maxTextChars = 2000, logger = () => {}
} = {}) {
  if (!dir) throw new Error('memory store 需要 dir');
  const root = path.resolve(dir);
  const conversations = new Map();
  let pruned = false;

  function ensureRoot() {
    fs.mkdirSync(root, { recursive: true });
  }

  function fileFor(key) {
    const name = dirName(key);
    if (!name) return null;
    return path.join(root, name, 'messages.jsonl');
  }

  function recallFileFor(key) {
    const name = dirName(key);
    if (!name) return null;
    return path.join(root, name, 'recall.json');
  }

  function normalize(raw, key) {
    if (!safeKey(key)) return null;
    const text = String(raw?.text ?? raw?.plain ?? '')
      .replace(/[\r\n\t]+/g, ' ')
      .replace(/\s{2,}/g, ' ')
      .trim()
      .slice(0, maxTextChars);
    if (!text) return null;
    const ts = Number(raw?.ts ?? raw?.time ?? raw?.timestamp);
    const id = raw?.messageId ?? raw?.msgId ?? raw?.message_id ?? null;
    // owner 只认显式标记：**不能**把 self（机器人自己发的）也算成主人，
    // 否则风格学习会拿自己的话当语料，越学越像自己。
    const owner = raw?.owner === true || raw?.isOwner === true;
    const imp = Number(raw?.imp);
    return {
      seq: Number(raw?.seq) || 0,
      id: id == null ? null : String(id),
      ts: Number.isFinite(ts) && ts > 0 ? ts : Date.now(),
      uid: String(raw?.uid ?? raw?.userId ?? raw?.user_id ?? ''),
      name: String(raw?.name ?? raw?.sender ?? raw?.card ?? '未知').slice(0, 60),
      text,
      owner,
      self: raw?.self === true || raw?.isSelf === true,
      // 重要性：调用方给了就用，没给就按启发式算（0 额外调用）
      imp: Number.isFinite(imp) ? Math.min(10, Math.max(1, Math.round(imp))) : heuristicImportance(text, { owner }),
      // 记忆强度 S：MemoryBank 的遗忘曲线里每召回一次 +1
      s: 1,
      media: Number(raw?.media) || (Array.isArray(raw?.mediaList) ? raw.mediaList.length : 0),
      replyTo: raw?.replyTo ?? null
    };
  }

  function stateFor(key) {
    const safe = safeKey(key);
    if (!safe) return null;
    let st = conversations.get(safe);
    if (st) return st;
    st = {
      key: safe, messages: [], index: null, seen: new Set(), loaded: false, lineCount: 0,
      recall: new Map(), recallTimer: null, recallDirty: false
    };
    conversations.set(safe, st);
    return st;
  }

  function readTailLines(file, maxBytes = TAIL_BYTES) {
    let fd;
    try {
      const stat = fs.statSync(file);
      const start = Math.max(0, stat.size - maxBytes);
      fd = fs.openSync(file, 'r');
      const buf = Buffer.alloc(stat.size - start);
      fs.readSync(fd, buf, 0, buf.length, start);
      let text = buf.toString('utf8');
      if (start > 0) {
        const idx = text.indexOf('\n');
        text = idx >= 0 ? text.slice(idx + 1) : '';
      }
      return text.split('\n').filter(Boolean);
    } catch {
      return [];
    } finally {
      if (fd != null) { try { fs.closeSync(fd); } catch {} }
    }
  }

  function loadRecall(key) {
    const file = recallFileFor(key);
    if (!file || !fs.existsSync(file)) return new Map();
    try {
      const raw = JSON.parse(fs.readFileSync(file, 'utf8'));
      const map = new Map();
      if (raw && typeof raw === 'object') {
        for (const [seq, info] of Object.entries(raw)) {
          const n = Number(seq);
          if (!Number.isSafeInteger(n)) continue;
          const s = Number(info?.s);
          const at = Number(info?.at);
          map.set(n, { s: Number.isFinite(s) ? Math.min(10, Math.max(1, s)) : 1, at: Number.isFinite(at) ? at : 0 });
        }
      }
      return map;
    } catch {
      return new Map();
    }
  }

  function load(key) {
    const st = stateFor(key);
    if (!st || st.loaded) return st;
    st.loaded = true;
    const file = fileFor(key);
    if (!file || !fs.existsSync(file)) return st;
    const lines = readTailLines(file);
    const parsed = [];
    for (const line of lines) {
      try {
        const msg = JSON.parse(line);
        if (msg && typeof msg === 'object' && msg.text) parsed.push(msg);
      } catch {}
    }
    st.lineCount = parsed.length;
    st.messages = parsed.slice(-maxCacheMessages);
    st.seen = new Set();
    for (const m of st.messages) {
      if (m.id) st.seen.add(`i:${m.id}`);
      if (m.seq) st.seen.add(`s:${m.seq}`);
    }
    // 召回记录合并进内存（JSONL 不动：它是 append-only 的底本）
    st.recall = loadRecall(key);
    for (const m of st.messages) {
      const rec = m.seq ? st.recall.get(m.seq) : null;
      if (rec) { m.s = rec.s; m.lastRecallAt = rec.at || 0; }
    }
    st.index = buildIndex(st.messages);
    return st;
  }

  function persistRecall(st) {
    st.recallDirty = false;
    try {
      const file = recallFileFor(st.key);
      if (!file) return;
      const obj = {};
      for (const [seq, info] of st.recall) obj[seq] = { s: info.s, at: info.at };
      fs.mkdirSync(path.dirname(file), { recursive: true });
      const tmp = `${file}.${process.pid}.tmp`;
      fs.writeFileSync(tmp, `${JSON.stringify(obj)}\n`, 'utf8');
      fs.renameSync(tmp, file);
    } catch (error) {
      logger(`[memory] 召回记录写入失败 ${st.key}: ${error?.message ?? error}`);
    }
  }

  function scheduleRecallSave(st) {
    st.recallDirty = true;
    if (st.recallTimer) return;
    st.recallTimer = setTimeout(() => {
      st.recallTimer = null;
      if (!st.recallDirty) return;
      persistRecall(st);
    }, RECALL_SAVE_DEBOUNCE_MS);
    st.recallTimer.unref?.();
  }

  /** 立刻把所有待写的召回记录落盘（退出前/测试里用；正常路径靠 3 秒防抖）。 */
  function flush() {
    for (const st of conversations.values()) {
      if (!st.recallDirty) continue;
      if (st.recallTimer) { clearTimeout(st.recallTimer); st.recallTimer = null; }
      persistRecall(st);
    }
  }

  /**
   * 追加一条消息。返回 {added:boolean, reason?:string}。
   * 重复消息（同 messageId 或同 seq）直接忽略——重投递、重启补读都会走到这里。
   */
  function append(key, raw) {
    const st = load(key);
    if (!st) return { added: false, reason: 'bad-key' };
    const msg = normalize(raw, key);
    if (!msg) return { added: false, reason: 'empty-or-bad' };
    if (msg.id && st.seen.has(`i:${msg.id}`)) return { added: false, reason: 'dup-id' };
    if (msg.seq && st.seen.has(`s:${msg.seq}`)) return { added: false, reason: 'dup-seq' };
    try {
      ensureRoot();
      const file = fileFor(key);
      fs.mkdirSync(path.dirname(file), { recursive: true });
      fs.appendFileSync(file, `${JSON.stringify(msg)}\n`, 'utf8');
    } catch (error) {
      logger(`[memory] 写入失败 ${key}: ${error?.message ?? error}`);
      return { added: false, reason: 'io' };
    }
    if (msg.id) st.seen.add(`i:${msg.id}`);
    if (msg.seq) st.seen.add(`s:${msg.seq}`);
    st.messages.push(msg);
    st.lineCount += 1;
    // 硬上限：超出就立刻裁掉最旧的。前端被裁 ⇒ 索引里的 doc 下标全部错位，
    // 只能作废重建（检索路径上惰性重建一次），不能 addDocument 硬接。
    if (st.messages.length > maxCacheMessages) {
      st.messages = st.messages.slice(-maxCacheMessages);
      st.index = null;
    } else if (st.index) {
      addDocument(st.index, msg.text);
    }
    return { added: true };
  }

  /** 最近 limit 条（可按 beforeSeq 向前翻）。 */
  function tail(key, { limit = 20, beforeSeq = null } = {}) {
    const st = load(key);
    if (!st) return [];
    const list = beforeSeq
      ? st.messages.filter((m) => !m.seq || m.seq < Number(beforeSeq))
      : st.messages;
    return list.slice(-Math.max(1, Math.min(200, Number(limit) || 20)));
  }

  /**
   * 检索。查询为空时退化成最近消息。
   * 命中会给这些消息「加一次记忆强度」（MemoryBank 的复习效应），异步落盘。
   */
  function search(key, query, opts = {}) {
    const st = load(key);
    if (!st) return [];
    const q = String(query ?? '').trim();
    if (!q) return tail(key, { limit: opts.limit }).map((m) => ({ message: m, score: 0, matched: [] }));
    if (!st.index || st.index.n !== st.messages.length) st.index = buildIndex(st.messages);
    const hits = searchIndex(st.index, st.messages, q, opts);
    bumpRecall(st, hits.map((h) => h.message));
    return hits;
  }

  /** 记一次召回：S += 1（上限 10），时间戳刷新 ⇒ 下次衰减更慢。 */
  function bumpRecall(st, messages) {
    if (!st || !Array.isArray(messages) || !messages.length) return;
    const now = Date.now();
    let changed = false;
    for (const m of messages) {
      if (!m || !m.seq) continue;
      const prev = st.recall.get(m.seq) ?? { s: Number(m.s) || 1, at: 0 };
      const next = { s: Math.min(10, (prev.s || 1) + 1), at: now };
      st.recall.set(m.seq, next);
      m.s = next.s;
      m.lastRecallAt = now;
      changed = true;
    }
    if (changed) scheduleRecallSave(st);
  }

  /** 统计型摘要（不调模型）。 */
  function digest(key, { sinceMs = 0, now = Date.now() } = {}) {
    const st = load(key);
    if (!st) return null;
    return digestMessages(st.messages, { sinceMs, now });
  }

  /** 主人（owner）说过的话，按时间倒序取最近 limit 条——风格学习的语料。 */
  function ownerSamples(key, { limit = 40 } = {}) {
    const st = load(key);
    if (!st) return [];
    return st.messages.filter((m) => m && m.owner === true).slice(-Math.max(1, Math.min(200, Number(limit) || 40)));
  }

  /** 非主人语料（做风格对照用，取最近 limit 条）。 */
  function peerSamples(key, { limit = 200 } = {}) {
    const st = load(key);
    if (!st) return [];
    return st.messages.filter((m) => m && m.owner !== true).slice(-Math.max(1, Math.min(500, Number(limit) || 200)));
  }

  function stats(key) {
    const st = load(key);
    if (!st) return null;
    return {
      key: st.key,
      cached: st.messages.length,
      lines: st.lineCount,
      ownerCount: st.messages.filter((m) => m.owner === true).length,
      firstTs: st.messages.length ? st.messages[0].ts : 0,
      lastTs: st.messages.length ? st.messages[st.messages.length - 1].ts : 0,
      indexTokens: st.index ? st.index.postings.size : 0,
      recalled: st.recall.size
    };
  }

  /** 启动时裁剪：删掉超过 retentionDays 的原文（整份重写，只在确实需要时做）。 */
  function prune(key, now = Date.now()) {
    const st = load(key);
    if (!st || !retentionDays) return { pruned: 0 };
    const file = fileFor(key);
    if (!file || !fs.existsSync(file)) return { pruned: 0 };
    const cutoff = now - retentionDays * DAY_MS;
    const lines = readTailLines(file, Number.MAX_SAFE_INTEGER);
    const kept = [];
    let dropped = 0;
    for (const line of lines) {
      try {
        const msg = JSON.parse(line);
        if (msg && msg.text && Number(msg.ts) >= cutoff) kept.push(line);
        else dropped += 1;
      } catch { dropped += 1; }
    }
    if (!dropped) return { pruned: 0 };
    try {
      const tmp = `${file}.${process.pid}.tmp`;
      fs.writeFileSync(tmp, kept.length ? `${kept.join('\n')}\n` : '', 'utf8');
      fs.renameSync(tmp, file);
      conversations.delete(st.key);
      logger(`[memory] ${st.key} 裁剪了 ${dropped} 条过期消息`);
    } catch (error) {
      logger(`[memory] 裁剪失败 ${st.key}: ${error?.message ?? error}`);
    }
    return { pruned: dropped };
  }

  /** 启动时调用一次：把磁盘上已有的会话都裁剪一遍（每个文件最多一次）。 */
  function pruneAll(now = Date.now()) {
    if (pruned) return [];
    pruned = true;
    const out = [];
    try {
      ensureRoot();
      for (const name of fs.readdirSync(root)) {
        const dirPath = path.join(root, name);
        if (!fs.statSync(dirPath).isDirectory()) continue;
        const m = /^(group|private)_(\d{1,20})$/.exec(name);
        if (!m) continue;
        const result = prune(`${m[1]}:${m[2]}`, now);
        if (result.pruned) out.push({ key: `${m[1]}:${m[2]}`, pruned: result.pruned });
      }
    } catch (error) {
      logger(`[memory] 启动裁剪异常: ${error?.message ?? error}`);
    }
    return out;
  }

  /** 列出所有已存在记忆的会话（控制台/自测用）。 */
  function listConversations() {
    try {
      ensureRoot();
      return fs.readdirSync(root)
        .map((name) => /^(group|private)_(\d{1,20})$/.exec(name))
        .filter(Boolean)
        .map((m) => `${m[1]}:${m[2]}`)
        .sort();
    } catch { return []; }
  }

  return {
    root, append, tail, search, digest, stats, prune, pruneAll, listConversations, load,
    ownerSamples, peerSamples, bumpRecall, flush
  };
}
