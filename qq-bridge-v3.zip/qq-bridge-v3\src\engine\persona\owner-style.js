// 从主人（ownerQQ）的语料里学「说话方式」：纯统计，零模型调用。
//
// 设计要点：
//   · 只做**可度量**的特征（句长、语气词、标点、口头禅、反问率），不做"感觉"；
//   · 口头禅用「主人语料的词频 ÷ 群友语料的词频」的差值找，避免把大众词标成口头禅；
//   · 输出是一行 ≤150 字符的注入文本（每轮都在上下文里，所以体积是硬约束）；
//   · 画像只是**覆盖层**：人格文件仍是父本，画像坏了大不了删掉重建。
//
// 之后可以接「模型提炼版」（每 24h 一次，放空闲时段）——它输出的 JSON 形状与
// analyzeStyle() 的结果一致，用 mergeStyle() 融合，不需要改注入侧。

const PARTICLE_LIST = ['吧', '呗', '啊', '呀', '嘛', '哈', '哦', '诶', '欸', '嗷', '捏', '咯', '哇', '捏', '滴'];
const STOP_WORDS = new Set([
  '这个', '那个', '什么', '怎么', '就是', '不是', '没有', '可以', '我们', '你们', '他们', '自己',
  '现在', '时候', '一个', '还是', '已经', '因为', '所以', '但是', '而且', '如果', '然后', '这样',
  '那样', '知道', '觉得', '应该', '可能', '真的', '有点', '一点', '这种', '那种', '一样', '东西'
]);

function median(nums) {
  if (!nums.length) return 0;
  const sorted = [...nums].sort((a, b) => a - b);
  const mid = Math.floor(sorted.length / 2);
  return sorted.length % 2 ? sorted[mid] : Math.round((sorted[mid - 1] + sorted[mid]) / 2);
}

/** 词的频次统计（用 bigram/词形切分，CJK 连续串 ≤8 字）。 */
function wordCounts(messages) {
  const counts = new Map();
  for (const m of messages) {
    const text = String(m?.text ?? m?.plain ?? '');
    for (const tok of splitWords(text)) counts.set(tok, (counts.get(tok) ?? 0) + 1);
  }
  return counts;
}

/** 与 index.js 的 tokenizeWords 同源逻辑，但额外产出 bigram：
 *  口头禅常常是长串里的一小截（"就这" 藏在 "就这就这" 里），
 *  只认整串会漏掉真实口癖。多出来的噪音由「≥3 条不同消息 + ≥25% 占比」过滤。 */
export function splitWords(text) {
  const src = String(text ?? '').toLowerCase();
  const out = new Set();
  for (const m of src.matchAll(/[a-z0-9][a-z0-9_+#.-]*/gi)) if (m[0].length >= 2) out.add(m[0]);
  let run = '';
  const flush = () => {
    if (run.length >= 2 && run.length <= 8) out.add(run);
    if (run.length >= 3) {
      for (let i = 0; i + 1 < run.length; i += 1) out.add(run.slice(i, i + 2));
    }
    run = '';
  };
  for (const ch of src) {
    if (/[\u3400-\u4dbf\u4e00-\u9fff\uf900-\ufaff\u3040-\u30ff]/.test(ch)) run += ch;
    else flush();
  }
  flush();
  return [...out];
}

/**
 * 分析主人风格。
 *
 * @param {Array<{text?:string,name?:string}>} ownerMessages 主人说过的话
 * @param {Array<{text?:string}>} [peerMessages] 群友语料（做对照，用于剥掉大众词）
 * @returns {null|{count:number, avgLen:number, medianLen:number, shortRate:number,
 *   questionRate:number, exclamRate:number, ellipsisRate:number, tildeRate:number,
 *   particles:string[], catchphrases:string[]}}
 */
export function analyzeStyle(ownerMessages, peerMessages = [], { excludeWords = [] } = {}) {
  const list = (Array.isArray(ownerMessages) ? ownerMessages : []).filter((m) => String(m?.text ?? m?.plain ?? '').trim());
  // 排除词：机器人自己的昵称/群名片。主人 @ 它时那串名字会混进主人语料，
  // 不排掉就会把「もう」「う嫌」这种碎片当成主人口头禅（真实数据里踩过）。
  const excludes = (Array.isArray(excludeWords) ? excludeWords : [])
    .map((w) => String(w ?? '').trim().toLowerCase())
    .filter((w) => w.length >= 2);
  if (!list.length) return null;
  const texts = list.map((m) => String(m?.text ?? m?.plain ?? ''));
  const lens = texts.map((t) => t.length);
  const total = texts.length;
  const has = (re) => texts.filter((t) => re.test(t)).length;

  // 语气词：出现在句末或独立成词的都算
  const particleHits = new Map();
  for (const t of texts) {
    for (const p of PARTICLE_LIST) {
      if (!t.includes(p)) continue;
      // 简单启发：语气词常在句末/逗号前
      const re = new RegExp(`${p}(?:[，,。.!！?？~～\\s]|$)`);
      if (re.test(t)) particleHits.set(p, (particleHits.get(p) ?? 0) + 1);
    }
  }
  const particles = [...particleHits.entries()]
    .filter(([, c]) => c >= Math.max(2, Math.ceil(total * 0.15)))
    .sort((a, b) => b[1] - a[1])
    .slice(0, 3)
    .map(([p]) => p);

  // 口头禅：主人语料里出现 ≥3 次、**至少在 3 条不同消息里**、占主人发言 ≥25%，
  // 且明显高于群友语料（剥掉大众词）。只按词频会把模板句的前缀误判成口癖。
  const ownerCounts = wordCounts(list);
  const ownerMsgCount = new Map();
  for (const m of list) {
    for (const w of new Set(splitWords(String(m?.text ?? m?.plain ?? '')))) {
      ownerMsgCount.set(w, (ownerMsgCount.get(w) ?? 0) + 1);
    }
  }
  const peerCounts = wordCounts(peerMessages);
  const peerTotal = Math.max(1, (Array.isArray(peerMessages) ? peerMessages : []).length);
  const ownerTotal = Math.max(1, total);
  const candidates = [];
  for (const [word, count] of ownerCounts) {
    if (count < 3 || word.length < 2) continue;
    if ((ownerMsgCount.get(word) ?? 0) < 3) continue;
    if (STOP_WORDS.has(word)) continue;
    if (/^[\d.]+$/.test(word)) continue;
    if (excludes.some((ex) => ex.includes(word))) continue;
    const ownerRate = count / ownerTotal;
    if (ownerRate < 0.25) continue;
    const peerRate = (peerCounts.get(word) ?? 0) / peerTotal;
    // 主人用得多、群友用得少 ⇒ 才可能是这个人的口头禅
    if (ownerRate < peerRate * 1.5) continue;
    candidates.push({ word, score: ownerRate - peerRate, count });
  }
  const catchphrases = candidates
    .sort((a, b) => b.score - a.score)
    .slice(0, 2)
    .map((c) => c.word);

  return {
    count: total,
    avgLen: Math.round(lens.reduce((a, b) => a + b, 0) / total),
    medianLen: median(lens),
    shortRate: Number((lens.filter((n) => n <= 10).length / total).toFixed(2)),
    questionRate: Number((has(/[?？]|吗|呢|吧\?/) / total).toFixed(2)),
    exclamRate: Number((has(/[!！]/) / total).toFixed(2)),
    ellipsisRate: Number((has(/…|\.{3}/) / total).toFixed(2)),
    tildeRate: Number((has(/[~～]/) / total).toFixed(2)),
    particles,
    catchphrases
  };
}

/**
 * 把画像压成一行注入文本（≤maxChars）。
 * 没数据或全没特征时返回空串——宁可不注入，也不塞一句正确的废话。
 */
export function buildStyleLine(style, { maxChars = 150 } = {}) {
  if (!style || !style.count) return '';
  const bits = [];
  if (style.medianLen && style.medianLen <= 12) bits.push(`句子偏短（中位 ${style.medianLen} 字）`);
  else if (style.medianLen >= 30) bits.push(`句子偏长（中位 ${style.medianLen} 字）`);
  if (style.particles?.length) bits.push(`常带「${style.particles.join('/')}」`);
  if (style.exclamRate >= 0.2) bits.push('爱用感叹号');
  else if (style.exclamRate <= 0.02) bits.push('几乎不用感叹号');
  if (style.ellipsisRate >= 0.2) bits.push('爱用省略号');
  if (style.tildeRate >= 0.2) bits.push('爱用波浪号');
  if (style.questionRate >= 0.3) bits.push('常反问');
  if (style.catchphrases?.length) bits.push(`口头禅「${style.catchphrases.join('」「')}」`);
  // 只有一条特征就不值得占 40 个字符（而且容易变成"正确的废话"）
  if (bits.length < 2) return '';
  const line = `【说话风格】主人平时：${bits.join('、')}。模仿语气，但别照抄原句。`;
  return line.length > maxChars ? `${line.slice(0, maxChars - 1)}…` : line;
}

/**
 * 立场一行（每轮都在上下文里，所以 ≤80 字）。
 * 刻意写成「可以转移话题、不能硬撒谎」：无脑吹会在群里被抓包，反而毁人设。
 */
export function buildStanceLine({ ownerQQ, ownerName = '', mode = 'support' } = {}) {
  // 名字只用于指认：群名片可能很长很花（真实数据里出现过 20 字的梗名），
  // 截到 12 字以内，否则这一行会把唤醒包撑得难看。
  const shortName = String(ownerName ?? '').trim().slice(0, 12);
  const who = shortName ? `${shortName}(QQ ${ownerQQ})` : `QQ ${ownerQQ}`;
  if (mode === 'naive') {
    return `【立场】主人是${who}。永远站主人这边，他说什么都先帮腔。`;
  }
  return `【立场】主人是${who}。默认站主人这边：他被人质疑/调侃时先帮他圆场或反击，不用中立腔调；但不编造事实——可以转移话题、打岔、玩笑化解，不能硬撒谎。`;
}

/**
 * 画像增量融合（给"模型提炼版"用）：new = α·旧 + (1-α)·新。
 * 列表型字段取新观察为主（新习惯优先），标量按加权平均。
 */
export function mergeStyle(prev, next, { alpha = 0.3 } = {}) {
  if (!prev) return next ?? null;
  if (!next) return prev;
  const mix = (a, b) => Math.round((Number(a) || 0) * alpha + (Number(b) || 0) * (1 - alpha));
  return {
    ...prev,
    count: Math.max(prev.count ?? 0, next.count ?? 0),
    avgLen: mix(prev.avgLen, next.avgLen),
    medianLen: mix(prev.medianLen, next.medianLen),
    shortRate: mix(prev.shortRate, next.shortRate),
    questionRate: mix(prev.questionRate, next.questionRate),
    exclamRate: mix(prev.exclamRate, next.exclamRate),
    ellipsisRate: mix(prev.ellipsisRate, next.ellipsisRate),
    tildeRate: mix(prev.tildeRate, next.tildeRate),
    particles: next.particles?.length ? next.particles : prev.particles,
    catchphrases: next.catchphrases?.length ? next.catchphrases : prev.catchphrases
  };
}

/** 是否需要重算画像：样本够 + （样本变化 ≥5 条 或 距上次 >6 小时）。 */
export function needsRefresh({ builtCount = 0, builtAt = 0, sampleCount = 0, minSamples = 6, now = Date.now() } = {}) {
  if (sampleCount < minSamples) return false;
  if (!builtAt) return true;
  if (sampleCount - builtCount >= 5) return true;
  return now - builtAt > 6 * 3600 * 1000;
}
